package com.nadi.traconotas

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File

object Exporter {
    private fun outDir(ctx: Context) = File(ctx.cacheDir, "export").apply { mkdirs() }
    private fun safe(name: String) = name.replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim().ifEmpty { "caderno" }

    fun pdf(ctx: Context, nb: Notebook, dir: File): File {
        val doc = PdfDocument()
        nb.pages.forEachIndexed { i, pg ->
            val info = PdfDocument.PageInfo.Builder(595, 842, i + 1).create()
            val page = doc.startPage(info)
            val c = page.canvas
            c.scale(595f / PAGE_W, 842f / PAGE_H)
            Renderer.drawPage(c, nb, pg, dir)
            doc.finishPage(page)
        }
        val f = File(outDir(ctx), safe(nb.title) + ".pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        return f
    }

    fun png(ctx: Context, nb: Notebook, pageIndex: Int, dir: File): File {
        val bmp = Bitmap.createBitmap(PAGE_W.toInt(), PAGE_H.toInt(), Bitmap.Config.ARGB_8888)
        Renderer.drawPage(Canvas(bmp), nb, nb.pages[pageIndex], dir)
        val f = File(outDir(ctx), safe(nb.title) + "_pag" + (pageIndex + 1) + ".png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return f
    }

    fun share(ctx: Context, f: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val i = Intent(Intent.ACTION_SEND)
            .setType(mime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Compartilhar ou salvar"))
    }
}
