package com.nadi.traconotas

import android.content.Context
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

const val PAGE_W = 1240f
const val PAGE_H = 1754f

object ElType {
    const val PEN = "pen"
    const val HL = "hl"
    const val LINE = "line"
    const val RECT = "rect"
    const val OVAL = "oval"
    const val ARROW = "arrow"
    const val TEXT = "text"
    const val IMAGE = "image"
}

fun segDist(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
    val dx = bx - ax
    val dy = by - ay
    val len2 = dx * dx + dy * dy
    if (len2 < 0.0001f) return hypot(px - ax, py - ay)
    val t = (((px - ax) * dx + (py - ay) * dy) / len2).coerceIn(0f, 1f)
    return hypot(px - (ax + t * dx), py - (ay + t * dy))
}

/**
 * Um elemento da página.
 * pen/hl: pts = x,y,pressão (trios) | formas: x1,y1,x2,y2 | texto: x,y | imagem: x,y,largura,altura
 */
class Element(
    var type: String,
    var color: Int,
    var width: Float,
    val pts: MutableList<Float> = ArrayList(),
    var text: String = "",
    var textSize: Float = 44f,
    var image: String = ""
) {
    var cache: Path? = null

    fun isInk() = type == ElType.PEN || type == ElType.HL
    fun isShape() = type == ElType.LINE || type == ElType.RECT || type == ElType.OVAL || type == ElType.ARROW

    fun copy(): Element = Element(type, color, width, ArrayList(pts), text, textSize, image)

    fun setFrom(o: Element) {
        color = o.color
        width = o.width
        pts.clear()
        pts.addAll(o.pts)
        text = o.text
        textSize = o.textSize
        image = o.image
        cache = null
    }

    fun bounds(): RectF {
        val r = RectF()
        if (isInk()) {
            var minX = Float.MAX_VALUE
            var minY = Float.MAX_VALUE
            var maxX = -Float.MAX_VALUE
            var maxY = -Float.MAX_VALUE
            var i = 0
            while (i + 1 < pts.size) {
                val x = pts[i]
                val y = pts[i + 1]
                if (x < minX) minX = x
                if (y < minY) minY = y
                if (x > maxX) maxX = x
                if (y > maxY) maxY = y
                i += 3
            }
            if (minX > maxX) return r
            r.set(minX, minY, maxX, maxY)
            r.inset(-width / 2f, -width / 2f)
        } else if (isShape()) {
            r.set(min(pts[0], pts[2]), min(pts[1], pts[3]), max(pts[0], pts[2]), max(pts[1], pts[3]))
            r.inset(-width / 2f, -width / 2f)
        } else if (type == ElType.TEXT) {
            val lines = text.split("\n")
            measurePaint.textSize = textSize
            var w = 0f
            for (l in lines) w = max(w, measurePaint.measureText(l))
            r.set(pts[0], pts[1], pts[0] + max(w, textSize * 0.5f), pts[1] + lines.size * textSize * LINE_H + textSize * 0.3f)
        } else if (type == ElType.IMAGE) {
            r.set(pts[0], pts[1], pts[0] + pts[2], pts[1] + pts[3])
        }
        return r
    }

    fun translate(dx: Float, dy: Float) {
        if (isInk()) {
            var i = 0
            while (i + 1 < pts.size) {
                pts[i] = pts[i] + dx
                pts[i + 1] = pts[i + 1] + dy
                i += 3
            }
        } else if (isShape()) {
            pts[0] = pts[0] + dx; pts[1] = pts[1] + dy
            pts[2] = pts[2] + dx; pts[3] = pts[3] + dy
        } else {
            pts[0] = pts[0] + dx; pts[1] = pts[1] + dy
        }
        cache = null
    }

    fun scaleAbout(ox: Float, oy: Float, s: Float) {
        if (isInk()) {
            var i = 0
            while (i + 1 < pts.size) {
                pts[i] = ox + (pts[i] - ox) * s
                pts[i + 1] = oy + (pts[i + 1] - oy) * s
                i += 3
            }
            width = max(0.5f, width * s)
        } else if (isShape()) {
            pts[0] = ox + (pts[0] - ox) * s; pts[1] = oy + (pts[1] - oy) * s
            pts[2] = ox + (pts[2] - ox) * s; pts[3] = oy + (pts[3] - oy) * s
            width = max(1f, width * s)
        } else if (type == ElType.TEXT) {
            pts[0] = ox + (pts[0] - ox) * s; pts[1] = oy + (pts[1] - oy) * s
            textSize = max(8f, textSize * s)
        } else {
            pts[0] = ox + (pts[0] - ox) * s; pts[1] = oy + (pts[1] - oy) * s
            pts[2] = max(10f, pts[2] * s); pts[3] = max(10f, pts[3] * s)
        }
        cache = null
    }

    fun hit(x: Float, y: Float, r: Float): Boolean {
        if (isInk()) {
            val tol = r + width / 2f
            val n = pts.size / 3
            if (n == 0) return false
            if (n == 1) return hypot(pts[0] - x, pts[1] - y) <= tol
            for (k in 0 until n - 1) {
                if (segDist(x, y, pts[k * 3], pts[k * 3 + 1], pts[k * 3 + 3], pts[k * 3 + 4]) <= tol) return true
            }
            return false
        }
        val tol = r + width / 2f
        return when (type) {
            ElType.LINE, ElType.ARROW -> segDist(x, y, pts[0], pts[1], pts[2], pts[3]) <= tol
            ElType.RECT -> {
                val l = min(pts[0], pts[2]); val t = min(pts[1], pts[3])
                val rr = max(pts[0], pts[2]); val b = max(pts[1], pts[3])
                segDist(x, y, l, t, rr, t) <= tol || segDist(x, y, rr, t, rr, b) <= tol ||
                    segDist(x, y, rr, b, l, b) <= tol || segDist(x, y, l, b, l, t) <= tol
            }
            ElType.OVAL -> {
                val cx = (pts[0] + pts[2]) / 2f; val cy = (pts[1] + pts[3]) / 2f
                val rx = kotlin.math.abs(pts[2] - pts[0]) / 2f; val ry = kotlin.math.abs(pts[3] - pts[1]) / 2f
                var hit = false
                var px0 = cx + rx; var py0 = cy
                for (k in 1..48) {
                    val a = (k / 48.0 * Math.PI * 2).toFloat()
                    val px1 = cx + rx * kotlin.math.cos(a); val py1 = cy + ry * kotlin.math.sin(a)
                    if (segDist(x, y, px0, py0, px1, py1) <= tol) { hit = true; break }
                    px0 = px1; py0 = py1
                }
                hit
            }
            else -> {
                val b = bounds()
                b.inset(-r, -r)
                b.contains(x, y)
            }
        }
    }

    /** Pontos usados pelo laço para decidir se o elemento foi selecionado. */
    fun anchors(): FloatArray {
        if (isInk()) {
            val n = pts.size / 3
            val a = FloatArray(n * 2)
            for (i in 0 until n) {
                a[i * 2] = pts[i * 3]
                a[i * 2 + 1] = pts[i * 3 + 1]
            }
            return a
        }
        val b = bounds()
        return floatArrayOf(b.centerX(), b.centerY())
    }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("t", type)
        o.put("c", color)
        o.put("w", width.toDouble())
        val a = JSONArray()
        for (p in pts) a.put(Math.round(p * 100f) / 100.0)
        o.put("p", a)
        if (text.isNotEmpty()) o.put("x", text)
        o.put("s", textSize.toDouble())
        if (image.isNotEmpty()) o.put("i", image)
        return o
    }

    companion object {
        const val LINE_H = 1.25f
        val measurePaint = Paint(Paint.ANTI_ALIAS_FLAG)

        fun fromJson(o: JSONObject): Element {
            val a = o.getJSONArray("p")
            val pts = ArrayList<Float>(a.length())
            for (i in 0 until a.length()) pts.add(a.getDouble(i).toFloat())
            return Element(
                o.getString("t"), o.getInt("c"), o.getDouble("w").toFloat(), pts,
                o.optString("x", ""), o.optDouble("s", 44.0).toFloat(), o.optString("i", "")
            )
        }
    }
}

class Page(val elements: MutableList<Element> = ArrayList()) {
    fun toJson(): JSONObject {
        val a = JSONArray()
        for (e in elements) a.put(e.toJson())
        return JSONObject().put("e", a)
    }

    companion object {
        fun fromJson(o: JSONObject): Page {
            val a = o.getJSONArray("e")
            val list = ArrayList<Element>(a.length())
            for (i in 0 until a.length()) list.add(Element.fromJson(a.getJSONObject(i)))
            return Page(list)
        }
    }
}

class Notebook(
    val id: String = UUID.randomUUID().toString(),
    var title: String = "Caderno",
    var paper: String = "lined",
    var paperColor: Int = 0xFFFFFFFF.toInt(),
    var modified: Long = System.currentTimeMillis(),
    val pages: MutableList<Page> = arrayListOf(Page())
) {
    fun toJson(): JSONObject {
        val a = JSONArray()
        for (p in pages) a.put(p.toJson())
        return JSONObject()
            .put("id", id).put("title", title).put("paper", paper)
            .put("paperColor", paperColor).put("modified", modified).put("pages", a)
    }

    companion object {
        fun fromJson(o: JSONObject): Notebook {
            val a = o.getJSONArray("pages")
            val pages = ArrayList<Page>()
            for (i in 0 until a.length()) pages.add(Page.fromJson(a.getJSONObject(i)))
            if (pages.isEmpty()) pages.add(Page())
            return Notebook(
                o.getString("id"), o.optString("title", "Caderno"), o.optString("paper", "lined"),
                o.optInt("paperColor", 0xFFFFFFFF.toInt()), o.optLong("modified", 0L), pages
            )
        }
    }
}

object Storage {
    fun root(ctx: Context): File = File(ctx.filesDir, "notebooks").apply { mkdirs() }
    fun dir(ctx: Context, id: String): File = File(root(ctx), id).apply { mkdirs() }

    fun list(ctx: Context): List<Notebook> =
        (root(ctx).listFiles()?.mapNotNull { load(ctx, it.name) } ?: emptyList()).sortedByDescending { it.modified }

    fun load(ctx: Context, id: String): Notebook? = try {
        val f = File(File(root(ctx), id), "notebook.json")
        if (f.exists()) Notebook.fromJson(JSONObject(f.readText())) else null
    } catch (e: Exception) {
        null
    }

    fun save(ctx: Context, nb: Notebook) {
        nb.modified = System.currentTimeMillis()
        val d = dir(ctx, nb.id)
        val tmp = File(d, "notebook.tmp")
        tmp.writeText(nb.toJson().toString())
        val f = File(d, "notebook.json")
        if (!tmp.renameTo(f)) {
            f.writeText(tmp.readText())
            tmp.delete()
        }
    }

    fun delete(ctx: Context, id: String) {
        File(root(ctx), id).deleteRecursively()
    }

    fun duplicate(ctx: Context, nb: Notebook): Notebook {
        val copyId = UUID.randomUUID().toString()
        File(root(ctx), nb.id).copyRecursively(File(root(ctx), copyId), overwrite = true)
        val copy = Notebook(copyId, nb.title + " (cópia)", nb.paper, nb.paperColor, System.currentTimeMillis(), nb.pages)
        save(ctx, copy)
        return copy
    }
}
