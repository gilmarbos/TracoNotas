package com.nadi.traconotas

import android.Manifest
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

class EditorActivity : AppCompatActivity(), NoteCanvasView.Listener {

    private lateinit var nb: Notebook
    private lateinit var dir: File
    private lateinit var prefs: SharedPreferences
    private lateinit var canvasView: NoteCanvasView
    private lateinit var titleView: TextView
    private lateinit var pageLabel: TextView
    private lateinit var undoBtn: IconButton
    private lateinit var redoBtn: IconButton
    private lateinit var micBtn: IconButton
    private lateinit var swatchScroll: HorizontalScrollView
    private lateinit var swatchRow: LinearLayout
    private lateinit var selScroll: HorizontalScrollView
    private val toolButtons = LinkedHashMap<Tool, IconButton>()

    private val handler = Handler(Looper.getMainLooper())
    private val saveRunnable = Runnable { save() }
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null

    private val penColors = longArrayOf(
        0xFF111111, 0xFF5F6670, 0xFFFFFFFF, 0xFF1F3A5F, 0xFF1E6FD9, 0xFF00897B,
        0xFF2E7D32, 0xFFF2B705, 0xFFE8833A, 0xFFD93025, 0xFFC2185B, 0xFF6A1B9A, 0xFF6D4C41
    ).map { it.toInt() }
    private val hlColors = longArrayOf(
        0xFFFFE066, 0xFFB9F27C, 0xFF8EE3F5, 0xFFFFA8D2, 0xFFFFC27A, 0xFFC7B8FF
    ).map { it.toInt() }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) importImage(uri)
    }
    private val pickPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importPdf(uri)
    }
    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording() else toast("Permita o microfone para gravar áudio")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val id = intent.getStringExtra("id")
        val loaded = if (id != null) Storage.load(this, id) else null
        if (loaded == null) {
            finish()
            return
        }
        nb = loaded
        dir = Storage.dir(this, nb.id)

        canvasView = NoteCanvasView(this)
        canvasView.notebook = nb
        canvasView.dir = dir
        canvasView.listener = this
        canvasView.stylusOnly = prefs.getBoolean("stylusOnly", false)
        canvasView.dynamicFinger = prefs.getBoolean("dynamicFinger", true)
        val defaultPen = if (Renderer.isDark(nb.paperColor)) Color.WHITE else 0xFF111111.toInt()
        canvasView.penColor = prefs.getInt("penColor", defaultPen)
        if (Renderer.isDark(nb.paperColor) == Renderer.isDark(canvasView.penColor)) canvasView.penColor = defaultPen
        canvasView.penWidth = prefs.getFloat("penWidth", 5f)
        canvasView.hlColor = prefs.getInt("hlColor", hlColors[0])
        canvasView.hlWidth = prefs.getFloat("hlWidth", 32f)
        canvasView.eraserSize = prefs.getFloat("eraserSize", 22f)
        canvasView.textSize = prefs.getFloat("textSize", 44f)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFEEF1F5.toInt())
        }

        // Barra superior
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(2), dp(2), 0)
        }
        top.addView(btn("back") { finish() })
        titleView = TextView(this).apply {
            text = nb.title
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF1F2933.toInt())
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(4), 0, dp(4), 0)
            setOnClickListener { rename() }
        }
        top.addView(titleView, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(btn("prev") { goPage(canvasView.pageIndex - 1) })
        pageLabel = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF3C4450.toInt())
            gravity = Gravity.CENTER
            minWidth = dp(44)
            setOnClickListener { jumpToPage() }
        }
        top.addView(pageLabel)
        top.addView(btn("next") { goPage(canvasView.pageIndex + 1) })
        micBtn = btn("mic") { toggleRecord() }
        top.addView(micBtn)
        top.addView(btn("share") { exportMenu() })
        top.addView(btn("more") { moreMenu(it) })
        root.addView(top)

        // Barra de ferramentas
        val toolsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        undoBtn = btn("undo") { canvasView.undo(); refreshUndo() }
        redoBtn = btn("redo") { canvasView.redo(); refreshUndo() }
        tools.addView(undoBtn)
        tools.addView(redoBtn)
        tools.addView(divider())
        addTool(tools, Tool.PEN, "pen")
        addTool(tools, Tool.HIGHLIGHTER, "marker")
        addTool(tools, Tool.ERASER, "eraser")
        addTool(tools, Tool.LASSO, "lasso")
        addTool(tools, Tool.SHAPE, "shape")
        addTool(tools, Tool.TEXT, "text")
        tools.addView(btn("image") { pickImage.launch("image/*") })
        addTool(tools, Tool.HAND, "pan")
        toolsScroll.addView(tools)
        root.addView(toolsScroll)

        // Paleta / opções da ferramenta
        swatchScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        swatchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(6), dp(2))
            minimumHeight = dp(42)
        }
        swatchScroll.addView(swatchRow)
        root.addView(swatchScroll)

        // Barra de seleção (laço)
        selScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            visibility = View.GONE
        }
        val selRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(6), dp(2))
        }
        selRow.addView(btn("trash") { canvasView.deleteSelection() })
        selRow.addView(btn("copy") { canvasView.duplicateSelection() })
        selRow.addView(divider())
        for (c in penColors) selRow.addView(SwatchView(this, c).apply { setOnClickListener { canvasView.recolorSelection(c) } })
        selRow.addView(divider())
        selRow.addView(btn("check") { canvasView.clearSelection() })
        selScroll.addView(selRow)
        root.addView(selScroll)

        root.addView(canvasView, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)

        refreshToolbar()
        updatePageLabel()
        refreshUndo()
    }

    // ---------- ajudantes de interface ----------

    private fun btn(kind: String, onClick: (View) -> Unit): IconButton =
        IconButton(this, kind).apply { setOnClickListener { v -> onClick(v) } }

    private fun divider(): View = View(this).apply {
        setBackgroundColor(0xFFC5CCD6.toInt())
        layoutParams = LinearLayout.LayoutParams(dp(1), dp(26)).apply { setMargins(dp(6), 0, dp(6), 0) }
    }

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        setTextColor(0xFF1F3A5F.toInt())
        background = roundBg(0xFFFFFFFF.toInt(), dp(14).toFloat(), 0xFFC5CCD6.toInt(), dp(1))
        setPadding(dp(12), dp(6), dp(12), dp(6))
        layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(6), 0, dp(4), 0) }
        setOnClickListener { onClick() }
    }

    private fun hint(label: String): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        setTextColor(0xFF5F6670.toInt())
        setPadding(dp(6), dp(8), dp(6), dp(8))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun addTool(parent: LinearLayout, t: Tool, icon: String) {
        val b = btn(icon) {
            if (canvasView.tool == t) {
                toolOptions(t)
            } else {
                canvasView.tool = t
                refreshToolbar()
            }
        }
        toolButtons[t] = b
        parent.addView(b)
    }

    private fun refreshToolbar() {
        for ((t, b) in toolButtons) b.active = (t == canvasView.tool)
        buildSwatches()
    }

    private fun refreshUndo() {
        undoBtn.alpha = if (canvasView.canUndo()) 1f else 0.35f
        redoBtn.alpha = if (canvasView.canRedo()) 1f else 0.35f
    }

    private fun updatePageLabel() {
        pageLabel.text = "${canvasView.pageIndex + 1}/${nb.pages.size}"
    }

    private fun buildSwatches() {
        swatchRow.removeAllViews()
        val t = canvasView.tool
        when (t) {
            Tool.ERASER -> {
                swatchRow.addView(hint("Passe sobre o traço para apagar"))
                swatchRow.addView(chip("Tamanho: ${canvasView.eraserSize.toInt()}") { sizeOptions(t) })
                return
            }
            Tool.LASSO -> {
                swatchRow.addView(hint("Circule para selecionar; arraste para mover, puxe a bolinha para redimensionar"))
                return
            }
            Tool.HAND -> {
                swatchRow.addView(hint("Arraste para mover a página. Pinça com dois dedos para zoom."))
                return
            }
            else -> {}
        }
        val colors = if (t == Tool.HIGHLIGHTER) hlColors else penColors
        val cur = if (t == Tool.HIGHLIGHTER) canvasView.hlColor else canvasView.penColor
        for (c in colors) {
            swatchRow.addView(SwatchView(this, c).apply {
                active = (c == cur)
                setOnClickListener { setToolColor(c) }
            })
        }
        if (cur !in colors) swatchRow.addView(SwatchView(this, cur).apply { active = true })
        swatchRow.addView(SwatchView(this, Color.WHITE, plus = true).apply {
            setOnClickListener { customColor(cur) { setToolColor(it) } }
        })
        when (t) {
            Tool.PEN -> swatchRow.addView(chip("Espessura: ${canvasView.penWidth.toInt()}") { sizeOptions(t) })
            Tool.HIGHLIGHTER -> swatchRow.addView(chip("Espessura: ${canvasView.hlWidth.toInt()}") { sizeOptions(t) })
            Tool.SHAPE -> {
                swatchRow.addView(chip("Forma: ${shapeName(canvasView.shapeType)}") { chooseShape() })
                swatchRow.addView(chip("Espessura: ${canvasView.penWidth.toInt()}") { sizeOptions(t) })
            }
            Tool.TEXT -> swatchRow.addView(chip("Tamanho: ${canvasView.textSize.toInt()}") { sizeOptions(t) })
            else -> {}
        }
    }

    private fun setToolColor(c: Int) {
        if (canvasView.tool == Tool.HIGHLIGHTER) canvasView.hlColor = c else canvasView.penColor = c
        savePrefs()
        buildSwatches()
    }

    private fun savePrefs() {
        prefs.edit()
            .putInt("penColor", canvasView.penColor)
            .putFloat("penWidth", canvasView.penWidth)
            .putInt("hlColor", canvasView.hlColor)
            .putFloat("hlWidth", canvasView.hlWidth)
            .putFloat("eraserSize", canvasView.eraserSize)
            .putFloat("textSize", canvasView.textSize)
            .putBoolean("stylusOnly", canvasView.stylusOnly)
            .putBoolean("dynamicFinger", canvasView.dynamicFinger)
            .apply()
    }

    private fun toolOptions(t: Tool) {
        if (t == Tool.SHAPE) chooseShape() else sizeOptions(t)
    }

    private fun sizeOptions(t: Tool) {
        when (t) {
            Tool.PEN, Tool.SHAPE -> sliderDialog("Espessura da caneta", 1, 40, canvasView.penWidth.toInt()) {
                canvasView.penWidth = it.toFloat(); savePrefs(); buildSwatches()
            }
            Tool.HIGHLIGHTER -> sliderDialog("Espessura do marca-texto", 8, 90, canvasView.hlWidth.toInt()) {
                canvasView.hlWidth = it.toFloat(); savePrefs(); buildSwatches()
            }
            Tool.ERASER -> sliderDialog("Tamanho da borracha", 6, 90, canvasView.eraserSize.toInt()) {
                canvasView.eraserSize = it.toFloat(); savePrefs(); buildSwatches()
            }
            Tool.TEXT -> sliderDialog("Tamanho do texto", 16, 140, canvasView.textSize.toInt()) {
                canvasView.textSize = it.toFloat(); savePrefs(); buildSwatches()
            }
            else -> {}
        }
    }

    private fun sliderDialog(title: String, lo: Int, hi: Int, value: Int, onSet: (Int) -> Unit) {
        val label = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            text = value.toString()
        }
        val seek = SeekBar(this)
        seek.max = hi - lo
        seek.progress = (value - lo).coerceIn(0, hi - lo)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                label.text = (progress + lo).toString()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(4))
            addView(label)
            addView(seek)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("Aplicar") { _, _ -> onSet(seek.progress + lo) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun shapeName(type: String) = when (type) {
        ElType.LINE -> "linha"
        ElType.OVAL -> "elipse"
        ElType.ARROW -> "seta"
        else -> "retângulo"
    }

    private fun chooseShape() {
        val names = arrayOf("Linha", "Retângulo", "Elipse", "Seta")
        val types = arrayOf(ElType.LINE, ElType.RECT, ElType.OVAL, ElType.ARROW)
        AlertDialog.Builder(this)
            .setTitle("Escolha a forma")
            .setItems(names) { _, i ->
                canvasView.shapeType = types[i]
                canvasView.tool = Tool.SHAPE
                refreshToolbar()
            }
            .show()
    }

    private fun customColor(initial: Int, onSet: (Int) -> Unit) {
        val preview = View(this)
        val bars = Array(3) { SeekBar(this).apply { max = 255 } }
        bars[0].progress = Color.red(initial)
        bars[1].progress = Color.green(initial)
        bars[2].progress = Color.blue(initial)
        fun update() {
            preview.background = roundBg(Color.rgb(bars[0].progress, bars[1].progress, bars[2].progress), dp(10).toFloat())
        }
        val l = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) = update()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        }
        for (b in bars) b.setOnSeekBarChangeListener(l)
        update()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(12), dp(20), 0)
        box.addView(preview, LinearLayout.LayoutParams(MATCH, dp(44)))
        val names = arrayOf("Vermelho", "Verde", "Azul")
        for (i in 0 until 3) {
            box.addView(TextView(this).apply { text = names[i]; setPadding(0, dp(10), 0, 0) })
            box.addView(bars[i])
        }
        AlertDialog.Builder(this)
            .setTitle("Cor personalizada")
            .setView(box)
            .setPositiveButton("Usar cor") { _, _ ->
                onSet(Color.rgb(bars[0].progress, bars[1].progress, bars[2].progress))
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- páginas ----------

    private fun goPage(i: Int) {
        if (i < 0) return
        if (i >= nb.pages.size) {
            addPage()
            return
        }
        canvasView.setPage(i)
        updatePageLabel()
    }

    private fun addPage() {
        save()
        nb.pages.add(canvasView.pageIndex + 1, Page())
        canvasView.resetHistory()
        canvasView.setPage(canvasView.pageIndex + 1)
        updatePageLabel()
        refreshUndo()
        scheduleSave()
        toast("Página ${canvasView.pageIndex + 1} criada")
    }

    private fun deletePage() {
        AlertDialog.Builder(this)
            .setTitle("Excluir página ${canvasView.pageIndex + 1}?")
            .setMessage("Esta ação não pode ser desfeita.")
            .setPositiveButton("Excluir") { _, _ ->
                val idx = canvasView.pageIndex
                if (nb.pages.size == 1) nb.pages[0] = Page() else nb.pages.removeAt(idx)
                canvasView.resetHistory()
                canvasView.setPage(min(idx, nb.pages.size - 1))
                updatePageLabel()
                refreshUndo()
                save()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun jumpToPage() {
        val names = Array(nb.pages.size) { "Página ${it + 1}" }
        AlertDialog.Builder(this)
            .setTitle("Ir para")
            .setItems(names) { _, i -> goPage(i) }
            .show()
    }

    // ---------- menus ----------

    private fun moreMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        val m = pm.menu
        m.add(0, 1, 0, "Adicionar página")
        m.add(0, 11, 1, "Importar PDF para anotar")
        m.add(0, 2, 1, "Excluir página")
        m.add(0, 3, 2, "Tipo de papel")
        m.add(0, 4, 3, "Cor do papel")
        m.add(0, 5, 4, "Gravações de áudio")
        m.add(0, 6, 5, "Selecionar tudo na página")
        m.add(0, 7, 6, "Só a caneta desenha (dedo move)").apply {
            isCheckable = true
            isChecked = canvasView.stylusOnly
        }
        m.add(0, 8, 7, "Traço dinâmico com o dedo").apply {
            isCheckable = true
            isChecked = canvasView.dynamicFinger
        }
        m.add(0, 9, 8, "Ajustar página à tela")
        m.add(0, 10, 9, "Renomear caderno")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> addPage()
                2 -> deletePage()
                3 -> choosePaper()
                4 -> choosePaperColor()
                5 -> showRecordings()
                6 -> { canvasView.selectAll(); refreshToolbar() }
                7 -> { canvasView.stylusOnly = !canvasView.stylusOnly; savePrefs() }
                8 -> { canvasView.dynamicFinger = !canvasView.dynamicFinger; savePrefs() }
                9 -> canvasView.fitWidth()
                10 -> rename()
                11 -> pickPdf.launch(arrayOf("application/pdf"))
            }
            true
        }
        pm.show()
    }

    private fun choosePaper() {
        val names = arrayOf("Em branco", "Pautado", "Quadriculado", "Pontilhado")
        val keys = arrayOf("blank", "lined", "grid", "dots")
        AlertDialog.Builder(this)
            .setTitle("Tipo de papel")
            .setSingleChoiceItems(names, keys.indexOf(nb.paper)) { d, i ->
                nb.paper = keys[i]
                canvasView.invalidate()
                scheduleSave()
                d.dismiss()
            }
            .show()
    }

    private fun choosePaperColor() {
        val names = PaperColors.names
        AlertDialog.Builder(this)
            .setTitle("Cor do papel")
            .setSingleChoiceItems(names, PaperColors.values.indexOf(nb.paperColor)) { d, i ->
                nb.paperColor = PaperColors.values[i]
                canvasView.invalidate()
                scheduleSave()
                d.dismiss()
            }
            .show()
    }

    private fun rename() {
        val et = EditText(this).apply {
            setText(nb.title)
            setSelection(text.length)
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(et, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        AlertDialog.Builder(this)
            .setTitle("Nome do caderno")
            .setView(box)
            .setPositiveButton("Salvar") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) {
                    nb.title = t
                    titleView.text = t
                    save()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun exportMenu() {
        val items = arrayOf("PDF do caderno inteiro", "Imagem PNG desta página")
        AlertDialog.Builder(this)
            .setTitle("Exportar e compartilhar")
            .setItems(items) { _, i ->
                save()
                try {
                    if (i == 0) Exporter.share(this, Exporter.pdf(this, nb, dir), "application/pdf")
                    else Exporter.share(this, Exporter.png(this, nb, canvasView.pageIndex, dir), "image/png")
                } catch (e: Exception) {
                    toast("Não foi possível exportar: ${e.message}")
                }
            }
            .show()
    }

    // ---------- imagem ----------

    private fun importImage(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp: Bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: throw IllegalStateException("imagem inválida")
            val orientation = try {
                contentResolver.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (e: Exception) {
                ExifInterface.ORIENTATION_NORMAL
            }
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) {
                val m = Matrix().apply { postRotate(deg) }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            val png = bmp.hasAlpha()
            val name = "img_${System.currentTimeMillis()}." + if (png) "png" else "jpg"
            File(dir, name).outputStream().use {
                bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 90, it)
            }
            canvasView.addImage(name, bmp.width, bmp.height)
            refreshToolbar()
        } catch (e: Exception) {
            toast("Não foi possível abrir a imagem")
        }
    }

    // ---------- PDF ----------

    private fun importPdf(uri: Uri) {
        toast("Importando PDF…")
        val insertAt = canvasView.pageIndex + 1
        Thread {
            val newPages = ArrayList<Page>()
            var error = false
            try {
                val pfd = contentResolver.openFileDescriptor(uri, "r") ?: throw IllegalStateException("pdf")
                val renderer = PdfRenderer(pfd)
                val stamp = System.currentTimeMillis()
                for (i in 0 until min(renderer.pageCount, 300)) {
                    val pg = renderer.openPage(i)
                    val w = 1240
                    val h = (w.toFloat() * pg.height / pg.width).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    pg.close()
                    val name = "pdf_${stamp}_$i.jpg"
                    File(dir, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                    bmp.recycle()
                    val s = min(PAGE_W / w, PAGE_H / h)
                    val dw = w * s
                    val dh = h * s
                    val el = Element(ElType.IMAGE, 0, 0f, arrayListOf((PAGE_W - dw) / 2f, (PAGE_H - dh) / 2f, dw, dh), image = name)
                    newPages.add(Page(arrayListOf(el)))
                }
                renderer.close()
                pfd.close()
            } catch (e: Exception) {
                error = true
            }
            runOnUiThread {
                if (error || newPages.isEmpty()) {
                    toast("Não foi possível abrir o PDF")
                } else {
                    nb.pages.addAll(min(insertAt, nb.pages.size), newPages)
                    canvasView.resetHistory()
                    canvasView.setPage(min(insertAt, nb.pages.size - 1))
                    updatePageLabel()
                    refreshUndo()
                    save()
                    toast("${newPages.size} páginas importadas. Escreva por cima!")
                }
            }
        }.start()
    }

    // ---------- áudio ----------

    private fun toggleRecord() {
        if (recorder != null) {
            stopRecording()
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startRecording()
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun startRecording() {
        try {
            val f = File(dir, "audio_${System.currentTimeMillis()}.m4a")
            val r = newRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(96000)
            r.setAudioSamplingRate(44100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r
            micBtn.kind = "rec"
            micBtn.invalidate()
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            toast("Gravando. Toque no quadrado vermelho para parar.")
        } catch (e: Exception) {
            recorder = null
            toast("Não foi possível iniciar a gravação")
        }
    }

    private fun stopRecording() {
        val r = recorder ?: return
        try { r.stop() } catch (e: Exception) { }
        r.release()
        recorder = null
        micBtn.kind = "mic"
        micBtn.invalidate()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        toast("Gravação salva neste caderno")
    }

    private fun showRecordings() {
        val files = (dir.listFiles()?.filter { it.name.startsWith("audio_") } ?: emptyList()).sortedBy { it.name }
        if (files.isEmpty()) {
            toast("Nenhuma gravação neste caderno. Use o microfone no topo.")
            return
        }
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))
        val names = files.map {
            val ts = it.name.removePrefix("audio_").removeSuffix(".m4a").toLongOrNull() ?: it.lastModified()
            "Gravação de " + fmt.format(Date(ts))
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Gravações")
            .setItems(names) { _, i -> play(files[i], names[i]) }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun play(f: File, label: String) {
        player?.release()
        player = null
        try {
            val mp = MediaPlayer()
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            toast("Não foi possível tocar a gravação")
            return
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Reproduzindo")
            .setMessage(label)
            .setPositiveButton("Parar") { _, _ -> player?.release(); player = null }
            .setNeutralButton("Excluir gravação") { _, _ ->
                player?.release(); player = null
                f.delete()
                toast("Gravação excluída")
            }
            .setOnCancelListener { player?.release(); player = null }
            .create()
        player?.setOnCompletionListener { dlg.dismiss(); player?.release(); player = null }
        dlg.show()
    }

    // ---------- salvar ----------

    private fun scheduleSave() {
        handler.removeCallbacks(saveRunnable)
        handler.postDelayed(saveRunnable, 1500)
    }

    private fun save() {
        handler.removeCallbacks(saveRunnable)
        if (::nb.isInitialized) Storage.save(this, nb)
    }

    override fun onPause() {
        super.onPause()
        save()
    }

    override fun onDestroy() {
        if (recorder != null) stopRecording()
        player?.release()
        player = null
        super.onDestroy()
    }

    // ---------- eventos da tela de desenho ----------

    override fun onContentChanged() {
        scheduleSave()
        refreshUndo()
    }

    override fun onSelectionChanged(count: Int) {
        selScroll.visibility = if (count > 0) View.VISIBLE else View.GONE
        swatchScroll.visibility = if (count > 0) View.GONE else View.VISIBLE
    }

    override fun onPageRestored(index: Int) {
        updatePageLabel()
    }

    override fun onTextRequest(x: Float, y: Float, existing: Element?) {
        val et = EditText(this).apply {
            setText(existing?.text ?: "")
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
            hint = "Digite o texto"
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(et, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        val b = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Inserir texto" else "Editar texto")
            .setView(box)
            .setPositiveButton("Inserir") { _, _ ->
                canvasView.commitText(
                    x, y, existing, et.text.toString(),
                    existing?.color ?: canvasView.penColor,
                    existing?.textSize ?: canvasView.textSize
                )
            }
            .setNegativeButton("Cancelar", null)
        if (existing != null) {
            b.setNeutralButton("Excluir") { _, _ -> canvasView.commitText(x, y, existing, "", 0, 0f) }
        }
        val dlg = b.create()
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        dlg.show()
        et.requestFocus()
    }
}

object PaperColors {
    val names = arrayOf("Branco", "Marfim", "Cinza claro", "Azul claro", "Grafite", "Verde lousa")
    val values = longArrayOf(0xFFFFFFFF, 0xFFFBF6E9, 0xFFF1F3F4, 0xFFEAF2FB, 0xFF262A30, 0xFF22403A).map { it.toInt() }
}
