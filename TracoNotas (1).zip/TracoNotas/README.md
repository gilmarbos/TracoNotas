# Traço Notas — caderno de anotações à mão para Android

App de anotações manuscritas com caneta sensível à pressão, marca-texto, borracha,
laço, formas, texto, imagens, PDF, gravação de áudio e exportação.

## Como gerar o APK (sem instalar nada no computador)

1. Crie uma conta gratuita em github.com e um repositório novo (pode ser privado).
2. Clique em "uploading an existing file" e arraste **todo o conteúdo** desta pasta
   (incluindo a pasta oculta `.github`). Dica: no Windows, ative "Itens ocultos" no Explorador.
3. Clique em "Commit changes". O GitHub começa a compilar sozinho.
4. Abra a aba **Actions** → "Gerar APK" → aguarde o ✓ verde (5 a 8 minutos).
5. Na parte de baixo da página, em **Artifacts**, baixe `TracoNotas-apk`. É um .zip com o
   arquivo `app-debug.apk` dentro.
6. Passe o APK para o celular e abra. Autorize "instalar apps desconhecidos" quando o Android pedir.

Alternativa: abra a pasta no Android Studio (Hedgehog ou mais novo) e use
Build → Build App Bundle(s)/APK(s) → Build APK(s).

## Novidades da versão 1.1

- Dez tamanhos de papel (A4, A5, A3, Carta, Ofício, paisagem, quadrado, 16:9, caderno longo)
- Seis tipos de caneta: tinteiro, esferográfica, lápis, pincel, caligrafia e hidrográfica
- Atalhos de espessura em bolinhas para caneta, marca-texto, formas e borracha
- Botão de câmera para fotografar e colar direto na página
- Envio direto pelo WhatsApp, por e-mail ou outros apps: PDF do caderno, imagem da página ou PDF com as gravações

## Como usar

- **Tela inicial:** "Novo caderno" escolhe nome, tipo de papel e cor. Toque longo num caderno
  para renomear, duplicar ou excluir.
- **Ferramentas:** caneta, marca-texto, borracha, laço, formas, texto, imagem e mão (mover).
  Tocar de novo na ferramenta ativa abre espessura/tamanho (nas formas, escolhe a forma).
- **Zoom:** pinça com dois dedos; dois dedos também arrastam a página.
- **Laço:** circule para selecionar. Arraste para mover, puxe a bolinha azul para
  redimensionar; a barra mostra excluir, duplicar e recolorir.
- **Páginas:** setas no topo; avançar na última página cria uma nova. Toque no número para pular.
- **Menu ⋮:** importar PDF para anotar, excluir página, tipo e cor de papel, gravações,
  selecionar tudo, "só a caneta desenha" (rejeição da palma para quem usa S Pen/stylus ativa),
  traço dinâmico com o dedo e renomear.
- **Microfone:** grava áudio no caderno (o quadrado vermelho para). Ouça em ⋮ → Gravações.
- **Compartilhar:** exporta o caderno inteiro em PDF ou a página atual em PNG.

Os cadernos ficam salvos no próprio celular e são gravados automaticamente.
