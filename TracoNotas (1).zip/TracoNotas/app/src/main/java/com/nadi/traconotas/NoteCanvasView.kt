package com.nadi.traconotas

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Region
import android.view.MotionEvent
import android.view.View
import org.json.JSONObject
import java.io.File
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

enum class Tool { PEN, HIGHLIGHTER, ERASER, LASSO, SHAPE, TEXT, HAND }

class NoteCanvasView(context: Context) : View(context) {

    interface Listener {
        fun onContentChanged()
        fun onSelectionChanged(count: Int)
        fun onTextRequest(x: Float, y: Float, existing: Element?)
        fun onPageRestored(index: Int)
    }

    var listener: Listener? = null
    lateinit var notebook: Notebook
    lateinit var dir: File
    var pageIndex = 0
        private set
    val page: Page get() = notebook.pages[pageIndex]

    var tool = Tool.PEN
        set(v) {
            field = v
            if (v != Tool.LASSO) clearSelection()
            invalidate()
        }
    var shapeType = ElType.RECT
    var penColor = Color.BLACK
    var penWidth = 5f
    var penStyle = PenStyles.FOUNTAIN
    var hlColor = 0xFFFFE066.toInt()
    var hlWidth = 32f
    var textSize = 44f
    var eraserSize = 22f
    var stylusOnly = false
    var dynamicFinger = true

    private val density = resources.displayMetrics.density
    private var scaleF = 1f
    private var tx = 0f
    private var ty = 0f
    private var lastWidth = 0

    // histórico
    private class Snap(val page: Int, val json: String)
    private val undoStack = ArrayDeque<Snap>()
    private val redoStack = ArrayDeque<Snap>()

    // toque
    private enum class Mode { NONE, DRAW, ERASE, LASSO, MOVE, RESIZE, SHAPE, PAN, GESTURE, TAP }
    private var mode = Mode.NONE
    private var current: Element? = null
    private var penIsStylus = false
    private var smoothP = 1f
    private val lassoPath = Path()
    private val lassoPts = ArrayList<Float>()
    val selection = ArrayList<Element>()
    private var selOrig: List<Element> = emptyList()
    private var selStart = RectF()
    private var lastPX = 0f
    private var lastPY = 0f
    private var lastSX = 0f
    private var lastSY = 0f
    private var downX = 0f
    private var downY = 0f
    private var eraseSnap: Snap? = null
    private var erasedAny = false
    private var cursorX = -1f
    private var cursorY = -1f
    private var gStartSpan = 1f
    private var gStartScale = 1f
    private var gPageX = 0f
    private var gPageY = 0f

    private val shadowPaint = Paint().apply { color = 0x26000000 }
    private val selPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFF2F6FB5.toInt()
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2F6FB5.toInt() }
    private val cursorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        color = 0x99555555.toInt()
    }

    // ---------- visualização ----------

    fun fitWidth() {
        if (width == 0 || !::notebook.isInitialized) return
        val pw = notebook.pageW
        val ph = notebook.pageH
        scaleF = min((width - 16 * density) / pw, if (pw > ph) (height - 16 * density) / ph else Float.MAX_VALUE)
        tx = (width - pw * scaleF) / 2f
        ty = 8 * density
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w != lastWidth) {
            lastWidth = w
            fitWidth()
        }
    }

    fun setPage(i: Int) {
        pageIndex = i.coerceIn(0, notebook.pages.size - 1)
        current = null
        selection.clear()
        listener?.onSelectionChanged(0)
        ty = 8 * density
        invalidate()
    }

    private fun toPX(x: Float) = (x - tx) / scaleF
    private fun toPY(y: Float) = (y - ty) / scaleF

    // ---------- desfazer / refazer ----------

    private fun snapshot() = Snap(pageIndex, page.toJson().toString())

    private fun pushUndo(s: Snap) {
        undoStack.addLast(s)
        while (undoStack.size > 80) undoStack.removeFirst()
        redoStack.clear()
    }

    fun checkpoint() = pushUndo(snapshot())
    fun canUndo() = undoStack.isNotEmpty()
    fun canRedo() = redoStack.isNotEmpty()

    fun undo() {
        val s = undoStack.removeLastOrNull() ?: return
        if (s.page >= notebook.pages.size) return
        redoStack.addLast(Snap(s.page, notebook.pages[s.page].toJson().toString()))
        restoreSnap(s)
    }

    fun redo() {
        val s = redoStack.removeLastOrNull() ?: return
        if (s.page >= notebook.pages.size) return
        undoStack.addLast(Snap(s.page, notebook.pages[s.page].toJson().toString()))
        restoreSnap(s)
    }

    private fun restoreSnap(s: Snap) {
        notebook.pages[s.page] = Page.fromJson(JSONObject(s.json))
        selection.clear()
        listener?.onSelectionChanged(0)
        if (s.page != pageIndex) {
            pageIndex = s.page
            listener?.onPageRestored(s.page)
        }
        changed()
    }

    fun resetHistory() {
        undoStack.clear()
        redoStack.clear()
    }

    private fun changed() {
        invalidate()
        listener?.onContentChanged()
    }

    // ---------- seleção ----------

    fun selectionBounds(): RectF? {
        if (selection.isEmpty()) return null
        val r = RectF(selection[0].bounds())
        for (i in 1 until selection.size) r.union(selection[i].bounds())
        return r
    }

    fun clearSelection() {
        if (selection.isNotEmpty()) {
            selection.clear()
            listener?.onSelectionChanged(0)
        }
        invalidate()
    }

    fun deleteSelection() {
        if (selection.isEmpty()) return
        checkpoint()
        val set = selection.toSet()
        page.elements.removeAll { it in set }
        selection.clear()
        listener?.onSelectionChanged(0)
        changed()
    }

    fun duplicateSelection() {
        if (selection.isEmpty()) return
        checkpoint()
        val copies = selection.map { it.copy().also { c -> c.translate(30f, 30f) } }
        page.elements.addAll(copies)
        selection.clear()
        selection.addAll(copies)
        listener?.onSelectionChanged(selection.size)
        changed()
    }

    fun recolorSelection(color: Int) {
        if (selection.isEmpty()) return
        checkpoint()
        for (e in selection) if (e.type != ElType.IMAGE) { e.color = color; e.cache = null }
        changed()
    }

    fun selectAll() {
        tool = Tool.LASSO
        selection.clear()
        selection.addAll(page.elements)
        listener?.onSelectionChanged(selection.size)
        invalidate()
    }

    // ---------- inserções ----------

    fun commitText(x: Float, y: Float, existing: Element?, value: String, color: Int, size: Float) {
        checkpoint()
        if (existing != null) {
            if (value.isBlank()) page.elements.remove(existing)
            else { existing.text = value; existing.color = color; existing.textSize = size }
        } else if (value.isNotBlank()) {
            page.elements.add(Element(ElType.TEXT, color, 0f, arrayListOf(x, y), value, size))
        }
        changed()
    }

    fun addImage(name: String, bw: Int, bh: Int) {
        checkpoint()
        val s = min(1f, notebook.pageW * 0.6f / max(1, bw))
        val w = bw * s
        val h = bh * s
        val cx = toPX(width / 2f).coerceIn(w / 2f, max(w / 2f, notebook.pageW - w / 2f))
        val cy = toPY(height / 2f).coerceIn(h / 2f, max(h / 2f, notebook.pageH - h / 2f))
        val el = Element(ElType.IMAGE, 0, 0f, arrayListOf(cx - w / 2f, cy - h / 2f, w, h), image = name)
        page.elements.add(el)
        tool = Tool.LASSO
        selection.clear()
        selection.add(el)
        listener?.onSelectionChanged(1)
        changed()
    }

    // ---------- toque ----------

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!::notebook.isInitialized) return false
        val action = e.actionMasked
        if (action == MotionEvent.ACTION_POINTER_DOWN) {
            if (e.pointerCount >= 2 && mode != Mode.GESTURE) {
                cancelCurrent()
                startGesture(e, -1)
            } else if (mode == Mode.GESTURE) {
                startGesture(e, -1)
            }
            return true
        }
        if (mode == Mode.GESTURE) {
            when (action) {
                MotionEvent.ACTION_MOVE -> if (e.pointerCount >= 2) doGesture(e)
                MotionEvent.ACTION_POINTER_UP -> if (e.pointerCount - 1 >= 2) startGesture(e, e.actionIndex)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = Mode.NONE
            }
            return true
        }
        val x = e.x
        val y = e.y
        val px = toPX(x)
        val py = toPY(y)
        when (action) {
            MotionEvent.ACTION_DOWN -> onDown(e, x, y, px, py)
            MotionEvent.ACTION_MOVE -> onMove(e, x, y, px, py)
            MotionEvent.ACTION_UP -> onUp(e, x, y, px, py)
            MotionEvent.ACTION_CANCEL -> { cancelCurrent(); mode = Mode.NONE; invalidate() }
        }
        return true
    }

    private fun cancelCurrent() {
        if (mode == Mode.ERASE && erasedAny) eraseSnap?.let { pushUndo(it); listener?.onContentChanged() }
        current = null
        lassoPath.reset()
        lassoPts.clear()
        cursorX = -1f
        if (mode == Mode.MOVE || mode == Mode.RESIZE) listener?.onContentChanged()
    }

    private fun focusSpan(e: MotionEvent, skip: Int): FloatArray {
        var sx = 0f
        var sy = 0f
        var n = 0
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            sx += e.getX(i); sy += e.getY(i); n++
        }
        if (n == 0) return floatArrayOf(0f, 0f, 1f)
        val fx = sx / n
        val fy = sy / n
        var d = 0f
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            d += hypot(e.getX(i) - fx, e.getY(i) - fy)
        }
        return floatArrayOf(fx, fy, d / n)
    }

    private fun startGesture(e: MotionEvent, skip: Int) {
        mode = Mode.GESTURE
        val f = focusSpan(e, skip)
        gStartSpan = max(f[2], 1f)
        gStartScale = scaleF
        gPageX = (f[0] - tx) / scaleF
        gPageY = (f[1] - ty) / scaleF
        invalidate()
    }

    private fun doGesture(e: MotionEvent) {
        val f = focusSpan(e, -1)
        scaleF = (gStartScale * f[2] / gStartSpan).coerceIn(0.15f, 8f)
        tx = f[0] - gPageX * scaleF
        ty = f[1] - gPageY * scaleF
        invalidate()
    }

    private fun onDown(e: MotionEvent, x: Float, y: Float, px: Float, py: Float) {
        downX = x; downY = y
        lastPX = px; lastPY = py
        lastSX = x; lastSY = y
        val tt = e.getToolType(0)
        val isStylus = tt == MotionEvent.TOOL_TYPE_STYLUS || tt == MotionEvent.TOOL_TYPE_ERASER
        if (tool == Tool.HAND || (stylusOnly && !isStylus && tool != Tool.TEXT)) {
            mode = Mode.PAN
            return
        }
        val buttonEraser = isStylus && (e.buttonState and MotionEvent.BUTTON_STYLUS_PRIMARY) != 0
        val effective = if (tt == MotionEvent.TOOL_TYPE_ERASER || buttonEraser) Tool.ERASER else tool
        when (effective) {
            Tool.PEN, Tool.HIGHLIGHTER -> {
                val hl = effective == Tool.HIGHLIGHTER
                current = Element(if (hl) ElType.HL else ElType.PEN, if (hl) hlColor else penColor, if (hl) hlWidth else penWidth,
                    style = if (hl) 0 else penStyle)
                penIsStylus = isStylus
                addPoint(px, py, e.pressure)
                mode = Mode.DRAW
            }
            Tool.ERASER -> {
                mode = Mode.ERASE
                eraseSnap = snapshot()
                erasedAny = false
                eraseAt(px, py)
                cursorX = x; cursorY = y
            }
            Tool.LASSO -> {
                val sb = selectionBounds()
                if (sb != null) {
                    val hr = 26 * density / scaleF
                    if (hypot(px - sb.right, py - sb.bottom) < hr * 1.4f) {
                        checkpoint()
                        mode = Mode.RESIZE
                        selOrig = selection.map { it.copy() }
                        selStart = RectF(sb)
                        return
                    }
                    val inflated = RectF(sb)
                    inflated.inset(-hr, -hr)
                    if (inflated.contains(px, py)) {
                        checkpoint()
                        mode = Mode.MOVE
                        return
                    }
                }
                clearSelection()
                mode = Mode.LASSO
                lassoPts.clear()
                lassoPts.add(px); lassoPts.add(py)
                lassoPath.reset()
                lassoPath.moveTo(px, py)
            }
            Tool.SHAPE -> {
                current = Element(shapeType, penColor, max(2f, penWidth), arrayListOf(px, py, px, py))
                mode = Mode.SHAPE
            }
            Tool.TEXT -> mode = Mode.TAP
            Tool.HAND -> mode = Mode.PAN
        }
        invalidate()
    }

    private fun addPoint(px: Float, py: Float, raw: Float) {
        val c = current ?: return
        val n = c.pts.size
        val p: Float = if (n >= 3) {
            val dx = px - c.pts[n - 3]
            val dy = py - c.pts[n - 2]
            val d2 = dx * dx + dy * dy
            if (d2 < 0.36f) return
            if (penIsStylus) raw.coerceIn(0.05f, 1f)
            else if ((dynamicFinger || c.style == PenStyles.BRUSH) && c.type == ElType.PEN) (1.05f - sqrt(d2) * scaleF / 70f).coerceIn(0.4f, 1f)
            else 1f
        } else {
            if (penIsStylus) raw.coerceIn(0.05f, 1f) else 1f
        }
        smoothP = if (n == 0) p else smoothP * 0.7f + p * 0.3f
        c.pts.add(px); c.pts.add(py); c.pts.add(smoothP)
        c.cache = null
    }

    private fun eraseAt(px: Float, py: Float) {
        val r = eraserSize / scaleF
        val iter = page.elements.iterator()
        while (iter.hasNext()) {
            val el = iter.next()
            if (el.type != ElType.IMAGE && el.hit(px, py, r)) {
                iter.remove()
                erasedAny = true
            }
        }
    }

    private fun onMove(e: MotionEvent, x: Float, y: Float, px: Float, py: Float) {
        when (mode) {
            Mode.DRAW -> {
                for (h in 0 until e.historySize) {
                    addPoint(toPX(e.getHistoricalX(h)), toPY(e.getHistoricalY(h)), e.getHistoricalPressure(h))
                }
                addPoint(px, py, e.pressure)
            }
            Mode.ERASE -> {
                for (h in 0 until e.historySize) eraseAt(toPX(e.getHistoricalX(h)), toPY(e.getHistoricalY(h)))
                eraseAt(px, py)
                cursorX = x; cursorY = y
            }
            Mode.LASSO -> {
                lassoPts.add(px); lassoPts.add(py)
                lassoPath.lineTo(px, py)
            }
            Mode.MOVE -> {
                val dx = px - lastPX
                val dy = py - lastPY
                for (el in selection) el.translate(dx, dy)
            }
            Mode.RESIZE -> {
                val d0 = hypot(selStart.width(), selStart.height()).coerceAtLeast(1f)
                val d1 = hypot(px - selStart.left, py - selStart.top)
                val s = (d1 / d0).coerceIn(0.1f, 10f)
                for (i in selection.indices) {
                    selection[i].setFrom(selOrig[i])
                    selection[i].scaleAbout(selStart.left, selStart.top, s)
                }
            }
            Mode.SHAPE -> current?.let {
                it.pts[2] = px
                it.pts[3] = py
            }
            Mode.PAN -> {
                tx += x - lastSX
                ty += y - lastSY
                lastSX = x; lastSY = y
            }
            else -> {}
        }
        lastPX = px; lastPY = py
        invalidate()
    }

    private fun onUp(e: MotionEvent, x: Float, y: Float, px: Float, py: Float) {
        when (mode) {
            Mode.DRAW -> {
                addPoint(px, py, e.pressure)
                current?.let {
                    if (it.pts.size >= 3) {
                        checkpoint()
                        it.cache = null
                        page.elements.add(it)
                        changed()
                    }
                }
                current = null
            }
            Mode.ERASE -> {
                if (erasedAny) eraseSnap?.let { pushUndo(it); listener?.onContentChanged() }
                eraseSnap = null
                cursorX = -1f
            }
            Mode.LASSO -> finishLasso()
            Mode.MOVE, Mode.RESIZE -> {
                listener?.onContentChanged()
                listener?.onSelectionChanged(selection.size)
            }
            Mode.SHAPE -> {
                current?.let {
                    if (hypot(it.pts[2] - it.pts[0], it.pts[3] - it.pts[1]) > 4f) {
                        checkpoint()
                        page.elements.add(it)
                        changed()
                    }
                }
                current = null
            }
            Mode.TAP -> {
                if (hypot(x - downX, y - downY) < 24 * density) {
                    val hitText = page.elements.lastOrNull { it.type == ElType.TEXT && it.bounds().contains(px, py) }
                    listener?.onTextRequest(px, py, hitText)
                }
            }
            else -> {}
        }
        mode = Mode.NONE
        invalidate()
    }

    private fun finishLasso() {
        if (lassoPts.size < 6) {
            lassoPath.reset()
            lassoPts.clear()
            return
        }
        lassoPath.close()
        val rb = RectF()
        lassoPath.computeBounds(rb, true)
        val region = Region()
        region.setPath(lassoPath, Region(rb.left.toInt() - 2, rb.top.toInt() - 2, rb.right.toInt() + 2, rb.bottom.toInt() + 2))
        selection.clear()
        for (el in page.elements) {
            val a = el.anchors()
            val total = a.size / 2
            if (total == 0) continue
            var inside = 0
            var k = 0
            while (k + 1 < a.size) {
                if (region.contains(a[k].toInt(), a[k + 1].toInt())) inside++
                k += 2
            }
            if (inside * 2 > total) selection.add(el)
        }
        lassoPath.reset()
        lassoPts.clear()
        listener?.onSelectionChanged(selection.size)
    }

    // ---------- desenho ----------

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(0xFFDDE1E7.toInt())
        if (!::notebook.isInitialized) return
        canvas.save()
        canvas.translate(tx, ty)
        canvas.scale(scaleF, scaleF)
        canvas.drawRect(5f, 7f, notebook.pageW + 5f, notebook.pageH + 7f, shadowPaint)
        canvas.save()
        canvas.clipRect(0f, 0f, notebook.pageW, notebook.pageH)
        Renderer.drawPage(canvas, notebook, page, dir)
        current?.let { Renderer.drawElement(canvas, it, dir) }
        canvas.restore()
        selPaint.strokeWidth = 2f / scaleF
        if (mode == Mode.LASSO) canvas.drawPath(lassoPath, selPaint)
        selectionBounds()?.let { b ->
            canvas.drawRect(b, selPaint)
            canvas.drawCircle(b.right, b.bottom, 11 * density / scaleF, handlePaint)
        }
        canvas.restore()
        if (cursorX >= 0f) canvas.drawCircle(cursorX, cursorY, eraserSize, cursorPaint)
    }
}
