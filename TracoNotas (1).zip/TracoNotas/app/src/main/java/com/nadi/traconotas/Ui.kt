package com.nadi.traconotas

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.View
import kotlin.math.min

const val MATCH = -1
const val WRAP = -2

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun roundBg(color: Int, radius: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        if (strokePx > 0) setStroke(strokePx, strokeColor)
    }

/** Botão com ícone desenhado em código (sem dependência de imagens). */
class IconButton(context: Context, var kind: String) : View(context) {
    var active = false
        set(v) { field = v; invalidate() }
    var tint = 0xFF2B313B.toInt()
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.8f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val f = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFD3E2F4.toInt() }

    init {
        isClickable = true
        isFocusable = true
        contentDescription = kind
        val tv = TypedValue()
        context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        if (tv.resourceId != 0) setBackgroundResource(tv.resourceId)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = (42 * d).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        if (active) c.drawRoundRect(3 * d, 3 * d, width - 3 * d, height - 3 * d, 10 * d, 10 * d, bg)
        val s = min(width, height) * 0.56f / 24f
        c.save()
        c.translate((width - 24 * s) / 2f, (height - 24 * s) / 2f)
        c.scale(s, s)
        p.color = if (active) 0xFF1F3A5F.toInt() else tint
        f.color = p.color
        Glyphs.draw(c, kind, p, f)
        c.restore()
    }
}

object Glyphs {
    fun draw(c: Canvas, k: String, p: Paint, f: Paint) {
        val path = Path()
        when (k) {
            "back" -> { path.moveTo(15f, 5f); path.lineTo(8f, 12f); path.lineTo(15f, 19f); c.drawPath(path, p) }
            "undo" -> undo(c, p)
            "redo" -> { c.save(); c.scale(-1f, 1f, 12f, 12f); undo(c, p); c.restore() }
            "prev" -> { path.moveTo(14f, 6f); path.lineTo(8f, 12f); path.lineTo(14f, 18f); c.drawPath(path, p) }
            "next" -> { path.moveTo(10f, 6f); path.lineTo(16f, 12f); path.lineTo(10f, 18f); c.drawPath(path, p) }
            "mic" -> {
                c.drawRoundRect(9f, 3f, 15f, 14f, 3f, 3f, p)
                path.moveTo(6f, 11f); path.cubicTo(6f, 18.5f, 18f, 18.5f, 18f, 11f); c.drawPath(path, p)
                c.drawLine(12f, 17f, 12f, 21f, p); c.drawLine(9f, 21f, 15f, 21f, p)
            }
            "rec" -> { f.color = 0xFFD93025.toInt(); c.drawRoundRect(6f, 6f, 18f, 18f, 2.5f, 2.5f, f) }
            "share" -> {
                c.drawCircle(18f, 5f, 2.2f, f); c.drawCircle(6f, 12f, 2.2f, f); c.drawCircle(18f, 19f, 2.2f, f)
                c.drawLine(8f, 11f, 16f, 6f, p); c.drawLine(8f, 13f, 16f, 18f, p)
            }
            "more" -> { c.drawCircle(12f, 5f, 1.8f, f); c.drawCircle(12f, 12f, 1.8f, f); c.drawCircle(12f, 19f, 1.8f, f) }
            "pen" -> {
                path.moveTo(4f, 20f); path.lineTo(5f, 15f); path.lineTo(16f, 4f); path.lineTo(20f, 8f); path.lineTo(9f, 19f); path.close()
                c.drawPath(path, p); c.drawLine(14f, 6f, 18f, 10f, p)
            }
            "marker" -> {
                path.moveTo(7f, 17f); path.lineTo(7f, 13f); path.lineTo(15f, 5f); path.lineTo(19f, 9f); path.lineTo(11f, 17f); path.close()
                c.drawPath(path, p)
                f.color = 0xFFF2C230.toInt(); c.drawRoundRect(3f, 19.5f, 21f, 22f, 1f, 1f, f)
            }
            "eraser" -> {
                path.moveTo(4f, 15f); path.lineTo(13f, 6f); path.lineTo(19f, 12f); path.lineTo(11f, 20f); path.lineTo(8f, 20f); path.close()
                c.drawPath(path, p); c.drawLine(8.5f, 10.5f, 14.5f, 16.5f, p); c.drawLine(11f, 20f, 20f, 20f, p)
            }
            "lasso" -> {
                val old = p.pathEffect
                p.pathEffect = DashPathEffect(floatArrayOf(2.5f, 2f), 0f)
                c.drawOval(3f, 4f, 21f, 15f, p)
                p.pathEffect = old
                path.moveTo(8f, 14f); path.quadTo(5f, 19f, 9f, 21f); c.drawPath(path, p)
            }
            "shape" -> { c.drawRect(3f, 3f, 12f, 12f, p); c.drawCircle(16f, 16f, 5f, p) }
            "text" -> { c.drawLine(5f, 5f, 19f, 5f, p); c.drawLine(12f, 5f, 12f, 20f, p); c.drawLine(9f, 20f, 15f, 20f, p) }
            "image" -> {
                c.drawRoundRect(3f, 5f, 21f, 19f, 2f, 2f, p); c.drawCircle(8f, 10f, 1.6f, f)
                path.moveTo(3.5f, 17f); path.lineTo(9f, 12.5f); path.lineTo(13f, 16f); path.lineTo(16f, 13f); path.lineTo(20.5f, 17f); c.drawPath(path, p)
            }
            "pan" -> {
                c.drawLine(12f, 3f, 12f, 21f, p); c.drawLine(3f, 12f, 21f, 12f, p)
                path.moveTo(9f, 6f); path.lineTo(12f, 3f); path.lineTo(15f, 6f)
                path.moveTo(9f, 18f); path.lineTo(12f, 21f); path.lineTo(15f, 18f)
                path.moveTo(6f, 9f); path.lineTo(3f, 12f); path.lineTo(6f, 15f)
                path.moveTo(18f, 9f); path.lineTo(21f, 12f); path.lineTo(18f, 15f)
                c.drawPath(path, p)
            }
            "trash" -> {
                c.drawRect(6f, 7f, 18f, 21f, p); c.drawLine(4f, 7f, 20f, 7f, p); c.drawLine(10f, 4f, 14f, 4f, p)
                c.drawLine(10f, 11f, 10f, 17f, p); c.drawLine(14f, 11f, 14f, 17f, p)
            }
            "copy" -> {
                c.drawRoundRect(8f, 8f, 20f, 20f, 2f, 2f, p)
                path.moveTo(16f, 8f); path.lineTo(16f, 4f); path.lineTo(4f, 4f); path.lineTo(4f, 16f); path.lineTo(8f, 16f); c.drawPath(path, p)
            }
            "check" -> { path.moveTo(5f, 12f); path.lineTo(10f, 17f); path.lineTo(19f, 7f); c.drawPath(path, p) }
            "camera" -> {
                path.moveTo(3f, 8f); path.lineTo(7f, 8f); path.lineTo(9f, 5f); path.lineTo(15f, 5f); path.lineTo(17f, 8f)
                path.lineTo(21f, 8f); path.lineTo(21f, 19f); path.lineTo(3f, 19f); path.close()
                c.drawPath(path, p); c.drawCircle(12f, 13f, 3.6f, p)
            }
        }
    }

    private fun undo(c: Canvas, p: Paint) {
        val path = Path()
        path.moveTo(8f, 5f); path.lineTo(4f, 9f); path.lineTo(8f, 13f)
        path.moveTo(4f, 9f); path.lineTo(14f, 9f); path.cubicTo(20.5f, 9f, 20.5f, 19f, 14f, 19f); path.lineTo(9f, 19f)
        c.drawPath(path, p)
    }
}

/** Bolinha de cor da paleta. */
class SwatchView(context: Context, val color: Int, private val plus: Boolean = false) : View(context) {
    var active = false
        set(v) { field = v; invalidate() }
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    init {
        isClickable = true
        contentDescription = if (plus) "Mais cores" else "Cor"
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = (38 * d).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 8 * d
        if (active) {
            ring.color = 0xFF1F3A5F.toInt(); ring.strokeWidth = 2.5f * d
            c.drawCircle(cx, cy, r + 4 * d, ring)
        }
        fill.color = color
        c.drawCircle(cx, cy, r, fill)
        ring.color = 0x33000000; ring.strokeWidth = 1f * d
        c.drawCircle(cx, cy, r, ring)
        if (plus) {
            ring.color = 0xFF5F6670.toInt(); ring.strokeWidth = 2f * d
            c.drawLine(cx - r * 0.5f, cy, cx + r * 0.5f, cy, ring)
            c.drawLine(cx, cy - r * 0.5f, cx, cy + r * 0.5f, ring)
        }
    }
}

/** Bolinha que mostra a espessura do traço (atalho de tamanho). */
class SizeDot(context: Context, val size: Float, private val maxSize: Float) : View(context) {
    var active = false
        set(v) { field = v; invalidate() }
    var dotColor = 0xFF2B313B.toInt()
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    init {
        isClickable = true
        contentDescription = "Espessura ${size.toInt()}"
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = (36 * d).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val maxR = min(width, height) / 2f - 7 * d
        val r = (1.5f * d + (maxR - 1.5f * d) * (size / maxSize)).coerceAtMost(maxR)
        if (active) {
            ring.color = 0xFF1F3A5F.toInt(); ring.strokeWidth = 2.2f * d
            c.drawCircle(cx, cy, maxR + 4 * d, ring)
        }
        fill.color = if (android.graphics.Color.luminance(dotColor) > 0.9f) 0xFFB0B6BE.toInt() else dotColor
        c.drawCircle(cx, cy, r, fill)
    }
}
