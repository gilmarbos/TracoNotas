package com.nadi.traconotas

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

class LibraryActivity : AppCompatActivity() {

    private lateinit var grid: GridLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFEEF1F5.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(14), dp(6))
        }
        header.addView(TextView(this).apply {
            text = getString(R.string.app_name)
            textSize = 26f
            setTypeface(Typeface.SERIF, Typeface.BOLD)
            setTextColor(0xFF1F3A5F.toInt())
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(MaterialButton(this).apply {
            text = "Novo caderno"
            isAllCaps = false
            setOnClickListener { newNotebook() }
        })
        root.addView(header)

        val scroll = ScrollView(this)
        grid = GridLayout(this).apply { setPadding(dp(8), dp(4), dp(8), dp(24)) }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun columns(): Int = max(2, resources.configuration.screenWidthDp / 170)

    private fun refresh() {
        grid.removeAllViews()
        grid.columnCount = columns()
        val list = Storage.list(this)
        if (list.isEmpty()) {
            grid.columnCount = 1
            grid.addView(TextView(this).apply {
                text = "Nenhum caderno ainda.\nToque em “Novo caderno” para começar a escrever."
                textSize = 16f
                setTextColor(0xFF5F6670.toInt())
                setPadding(dp(12), dp(40), dp(12), dp(12))
            })
            return
        }
        val tileW = (resources.displayMetrics.widthPixels - dp(16)) / grid.columnCount - dp(28)
        for (nb in list) grid.addView(tile(nb, tileW))
    }

    private fun tile(nb: Notebook, w: Int): View {
        val fmt = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(8))
            background = roundBg(0xFFFFFFFF.toInt(), dp(6).toFloat(), 0xFFD5DBE3.toInt(), dp(1))
            isClickable = true
        }
        val thumb = ImageView(this).apply {
            setImageBitmap(Renderer.thumbnail(nb, Storage.dir(this@LibraryActivity, nb.id), w))
            scaleType = ImageView.ScaleType.FIT_XY
        }
        box.addView(thumb, LinearLayout.LayoutParams(w, (w * nb.pageH / nb.pageW).toInt()))
        box.addView(TextView(this).apply {
            text = nb.title
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF1F2933.toInt())
            maxLines = 1
            setPadding(dp(2), dp(6), dp(2), 0)
        })
        val pages = (if (nb.pages.size == 1) "1 página" else "${nb.pages.size} páginas") +
            PaperSizes.indexOf(nb.pageW, nb.pageH).let { if (it >= 0) ", " + PaperSizes.names[it] else "" }
        box.addView(TextView(this).apply {
            text = "$pages\n${fmt.format(Date(nb.modified))}"
            textSize = 12f
            setTextColor(0xFF6B7380.toInt())
            setPadding(dp(2), 0, dp(2), 0)
        })
        box.layoutParams = GridLayout.LayoutParams().apply {
            width = w + dp(12)
            setMargins(dp(8), dp(8), dp(8), dp(8))
        }
        box.setOnClickListener { open(nb.id) }
        box.setOnLongClickListener { options(nb); true }
        return box
    }

    private fun open(id: String) {
        startActivity(Intent(this, EditorActivity::class.java).putExtra("id", id))
    }

    private fun options(nb: Notebook) {
        AlertDialog.Builder(this)
            .setTitle(nb.title)
            .setItems(arrayOf("Abrir", "Renomear", "Duplicar", "Excluir")) { _, i ->
                when (i) {
                    0 -> open(nb.id)
                    1 -> rename(nb)
                    2 -> { Storage.duplicate(this, nb); refresh() }
                    3 -> confirmDelete(nb)
                }
            }
            .show()
    }

    private fun rename(nb: Notebook) {
        val et = EditText(this).apply { setText(nb.title) }
        val box = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(et, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        AlertDialog.Builder(this)
            .setTitle("Nome do caderno")
            .setView(box)
            .setPositiveButton("Salvar") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) {
                    nb.title = t
                    Storage.save(this, nb)
                    refresh()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirmDelete(nb: Notebook) {
        AlertDialog.Builder(this)
            .setTitle("Excluir “${nb.title}”?")
            .setMessage("O caderno, as imagens e as gravações serão apagados.")
            .setPositiveButton("Excluir") { _, _ -> Storage.delete(this, nb.id); refresh() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun radioGroup(labels: Array<String>, keys: Array<String>, checked: Int): RadioGroup {
        val rg = RadioGroup(this)
        labels.forEachIndexed { i, l ->
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                text = l
                tag = keys[i]
            }
            rg.addView(rb)
            if (i == checked) rg.check(rb.id)
        }
        return rg
    }

    private fun newNotebook() {
        val count = Storage.list(this).size
        val title = EditText(this).apply { setText("Caderno ${count + 1}") }
        val paper = radioGroup(
            arrayOf("Em branco", "Pautado", "Quadriculado", "Pontilhado"),
            arrayOf("blank", "lined", "grid", "dots"), 1
        )
        val color = radioGroup(PaperColors.names, PaperColors.names, 0)
        val size = radioGroup(PaperSizes.names, PaperSizes.names, 0)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(title, LinearLayout.LayoutParams(MATCH, WRAP))
            addView(TextView(this@LibraryActivity).apply { text = "Papel"; setPadding(0, dp(12), 0, 0); setTypeface(typeface, Typeface.BOLD) })
            addView(paper)
            addView(TextView(this@LibraryActivity).apply { text = "Tamanho do papel"; setPadding(0, dp(12), 0, 0); setTypeface(typeface, Typeface.BOLD) })
            addView(size)
            addView(TextView(this@LibraryActivity).apply { text = "Cor do papel"; setPadding(0, dp(12), 0, 0); setTypeface(typeface, Typeface.BOLD) })
            addView(color)
        }
        val scroll = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this)
            .setTitle("Novo caderno")
            .setView(scroll)
            .setPositiveButton("Criar") { _, _ ->
                val paperKey = paper.findViewById<RadioButton>(paper.checkedRadioButtonId)?.tag as? String ?: "lined"
                val colorName = color.findViewById<RadioButton>(color.checkedRadioButtonId)?.tag as? String
                val colorIdx = max(0, PaperColors.names.indexOf(colorName))
                val sizeName = size.findViewById<RadioButton>(size.checkedRadioButtonId)?.tag as? String
                val dims = PaperSizes.dims[max(0, PaperSizes.names.indexOf(sizeName))]
                val nb = Notebook(
                    title = title.text.toString().trim().ifEmpty { "Caderno ${count + 1}" },
                    paper = paperKey,
                    paperColor = PaperColors.values[colorIdx],
                    pageW = dims[0],
                    pageH = dims[1]
                )
                Storage.save(this, nb)
                open(nb.id)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
