package com.nadi.traconotas

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.LruCache
import java.io.File
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

object Renderer {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private val bitmaps = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 6).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun isDark(color: Int) = Color.luminance(color) < 0.35f

    fun drawPaper(c: Canvas, paper: String, color: Int, W: Float, H: Float) {
        fill.color = color
        c.drawRect(0f, 0f, W, H, fill)
        val dark = isDark(color)
        val lineColor = if (dark) 0xFF4A5260.toInt() else 0xFFC9D6E3.toInt()
        linePaint.color = lineColor
        linePaint.strokeWidth = 2f
        when (paper) {
            "lined" -> {
                var y = 180f
                while (y < H - 60f) {
                    c.drawLine(60f, y, W - 60f, y, linePaint)
                    y += 62f
                }
                linePaint.color = if (dark) 0x88B05050.toInt() else 0x88E57373.toInt()
                c.drawLine(150f, 0f, 150f, H, linePaint)
            }
            "grid" -> {
                var x = 20f
                while (x < W) { c.drawLine(x, 0f, x, H, linePaint); x += 50f }
                var y = 27f
                while (y < H) { c.drawLine(0f, y, W, y, linePaint); y += 50f }
            }
            "dots" -> {
                fill.color = lineColor
                var y = 52f
                while (y < H) {
                    var x = 45f
                    while (x < W) { c.drawCircle(x, y, 2.8f, fill); x += 50f }
                    y += 50f
                }
            }
        }
    }

    fun drawPage(c: Canvas, nb: Notebook, page: Page, dir: File) {
        drawPaper(c, nb.paper, nb.paperColor, nb.pageW, nb.pageH)
        for (e in page.elements) if (e.type == ElType.HL) drawElement(c, e, dir)
        for (e in page.elements) if (e.type != ElType.HL) drawElement(c, e, dir)
    }

    /** Meia espessura do traço no ponto i, conforme o tipo de caneta. dx/dy = direção do traço. */
    fun halfWidth(e: Element, i: Int, dx: Float = 1f, dy: Float = 0f): Float {
        val p = e.pts[i * 3 + 2]
        return when (e.style) {
            PenStyles.BALLPOINT, PenStyles.FELT -> e.width / 2f
            PenStyles.PENCIL -> e.width * (0.6f + 0.4f * p) / 2f
            PenStyles.BRUSH -> e.width * (0.12f + 1.4f * p * p) / 2f
            PenStyles.CALLIGRAPHY -> {
                val len = sqrt(dx * dx + dy * dy)
                val s = if (len < 0.0001f) 0.5f else kotlin.math.abs((dx - dy) / (len * 1.4142f))
                e.width * (0.12f + 0.88f * s) / 2f
            }
            else -> e.width * (0.35f + 0.65f * p) / 2f
        }
    }

    private fun penAlpha(e: Element) = when (e.style) {
        PenStyles.PENCIL -> 170
        PenStyles.FELT -> 225
        else -> 255
    }

    fun drawElement(c: Canvas, e: Element, dir: File) {
        when (e.type) {
            ElType.PEN -> {
                fill.color = e.color
                fill.alpha = penAlpha(e)
                val path = e.cache ?: inkPath(e).also { e.cache = it }
                c.drawPath(path, fill)
                val n = e.pts.size / 3
                if (n > 0 && e.style != PenStyles.CALLIGRAPHY) {
                    c.drawCircle(e.pts[0], e.pts[1], halfWidth(e, 0), fill)
                    c.drawCircle(e.pts[(n - 1) * 3], e.pts[(n - 1) * 3 + 1], halfWidth(e, n - 1), fill)
                }
                fill.alpha = 255
            }
            ElType.HL -> {
                stroke.color = e.color
                stroke.alpha = 110
                stroke.strokeWidth = e.width
                val path = e.cache ?: smoothPath(e).also { e.cache = it }
                c.drawPath(path, stroke)
            }
            ElType.LINE -> {
                prep(e)
                c.drawLine(e.pts[0], e.pts[1], e.pts[2], e.pts[3], stroke)
            }
            ElType.RECT -> {
                prep(e)
                c.drawRect(min(e.pts[0], e.pts[2]), min(e.pts[1], e.pts[3]), max(e.pts[0], e.pts[2]), max(e.pts[1], e.pts[3]), stroke)
            }
            ElType.OVAL -> {
                prep(e)
                c.drawOval(RectF(min(e.pts[0], e.pts[2]), min(e.pts[1], e.pts[3]), max(e.pts[0], e.pts[2]), max(e.pts[1], e.pts[3])), stroke)
            }
            ElType.ARROW -> {
                prep(e)
                val x1 = e.pts[0]; val y1 = e.pts[1]; val x2 = e.pts[2]; val y2 = e.pts[3]
                c.drawLine(x1, y1, x2, y2, stroke)
                val ang = atan2(y2 - y1, x2 - x1)
                val len = max(18f, e.width * 4f)
                for (s in floatArrayOf(-1f, 1f)) {
                    val a = ang + Math.PI.toFloat() - s * 0.45f
                    c.drawLine(x2, y2, x2 + len * cos(a), y2 + len * sin(a), stroke)
                }
            }
            ElType.TEXT -> {
                textPaint.color = e.color
                textPaint.textSize = e.textSize
                val lines = e.text.split("\n")
                for ((i, l) in lines.withIndex()) {
                    c.drawText(l, e.pts[0], e.pts[1] + e.textSize * (1f + i * Element.LINE_H) - e.textSize * 0.1f, textPaint)
                }
            }
            ElType.IMAGE -> {
                val r = RectF(e.pts[0], e.pts[1], e.pts[0] + e.pts[2], e.pts[1] + e.pts[3])
                val bmp = bitmap(dir, e.image)
                if (bmp != null) {
                    c.drawBitmap(bmp, null, r, bmpPaint)
                } else {
                    stroke.color = Color.LTGRAY
                    stroke.strokeWidth = 2f
                    c.drawRect(r, stroke)
                }
            }
        }
    }

    private fun prep(e: Element) {
        stroke.color = e.color
        stroke.strokeWidth = e.width
    }

    private fun bitmap(dir: File, name: String): Bitmap? {
        if (name.isEmpty()) return null
        val f = File(dir, name)
        val key = f.absolutePath
        bitmaps.get(key)?.let { return it }
        val b = BitmapFactory.decodeFile(key) ?: return null
        bitmaps.put(key, b)
        return b
    }

    /** Contorno de traço com espessura variável (pressão / velocidade). */
    fun inkPath(e: Element): Path {
        val path = Path()
        val n = e.pts.size / 3
        if (n == 0) return path
        if (n == 1) {
            path.addCircle(e.pts[0], e.pts[1], max(0.5f, halfWidth(e, 0)), Path.Direction.CW)
            return path
        }
        val lx = FloatArray(n); val ly = FloatArray(n)
        val rx = FloatArray(n); val ry = FloatArray(n)
        var nx = 0f
        var ny = -1f
        for (i in 0 until n) {
            val a = max(0, i - 1)
            val b = min(n - 1, i + 1)
            val dx = e.pts[b * 3] - e.pts[a * 3]
            val dy = e.pts[b * 3 + 1] - e.pts[a * 3 + 1]
            val len = sqrt(dx * dx + dy * dy)
            if (len > 0.0001f) { nx = -dy / len; ny = dx / len }
            val hw = halfWidth(e, i, dx, dy)
            val x = e.pts[i * 3]
            val y = e.pts[i * 3 + 1]
            lx[i] = x + nx * hw; ly[i] = y + ny * hw
            rx[i] = x - nx * hw; ry[i] = y - ny * hw
        }
        path.moveTo(lx[0], ly[0])
        for (i in 1 until n - 1) path.quadTo(lx[i], ly[i], (lx[i] + lx[i + 1]) / 2f, (ly[i] + ly[i + 1]) / 2f)
        path.lineTo(lx[n - 1], ly[n - 1])
        path.lineTo(rx[n - 1], ry[n - 1])
        for (i in n - 2 downTo 1) path.quadTo(rx[i], ry[i], (rx[i] + rx[i - 1]) / 2f, (ry[i] + ry[i - 1]) / 2f)
        path.lineTo(rx[0], ry[0])
        path.close()
        path.fillType = Path.FillType.WINDING
        return path
    }

    fun smoothPath(e: Element): Path {
        val p = Path()
        val n = e.pts.size / 3
        if (n == 0) return p
        p.moveTo(e.pts[0], e.pts[1])
        if (n == 1) {
            p.lineTo(e.pts[0] + 0.1f, e.pts[1])
            return p
        }
        for (i in 1 until n - 1) {
            val x = e.pts[i * 3]; val y = e.pts[i * 3 + 1]
            val x2 = e.pts[(i + 1) * 3]; val y2 = e.pts[(i + 1) * 3 + 1]
            p.quadTo(x, y, (x + x2) / 2f, (y + y2) / 2f)
        }
        p.lineTo(e.pts[(n - 1) * 3], e.pts[(n - 1) * 3 + 1])
        return p
    }

    fun thumbnail(nb: Notebook, dir: File, w: Int): Bitmap {
        val bw = max(1, w)
        val bh = max(1, (bw * nb.pageH / nb.pageW).toInt())
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(bw / nb.pageW, bh / nb.pageH)
        drawPage(c, nb, nb.pages[0], dir)
        return bmp
    }
}
