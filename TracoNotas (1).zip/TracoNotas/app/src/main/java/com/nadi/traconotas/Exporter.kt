package com.nadi.traconotas

import android.content.Context
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File

object Exporter {
    private fun outDir(ctx: Context) = File(ctx.cacheDir, "export").apply { mkdirs() }
    private fun safe(name: String) = name.replace(Regex("[^\\p{L}\\p{N} _-]"), "").trim().ifEmpty { "caderno" }

    fun pdf(ctx: Context, nb: Notebook, dir: File): File {
        val doc = PdfDocument()
        nb.pages.forEachIndexed { i, pg ->
            val ptW = (nb.pageW * 0.48f).toInt()
            val ptH = (nb.pageH * 0.48f).toInt()
            val info = PdfDocument.PageInfo.Builder(ptW, ptH, i + 1).create()
            val page = doc.startPage(info)
            val c = page.canvas
            c.scale(ptW / nb.pageW, ptH / nb.pageH)
            Renderer.drawPage(c, nb, pg, dir)
            doc.finishPage(page)
        }
        val f = File(outDir(ctx), safe(nb.title) + ".pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        return f
    }

    fun png(ctx: Context, nb: Notebook, pageIndex: Int, dir: File): File {
        val bmp = Bitmap.createBitmap(nb.pageW.toInt(), nb.pageH.toInt(), Bitmap.Config.ARGB_8888)
        Renderer.drawPage(Canvas(bmp), nb, nb.pages[pageIndex], dir)
        val f = File(outDir(ctx), safe(nb.title) + "_pag" + (pageIndex + 1) + ".png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return f
    }

    /** Copia as gravações com nomes legíveis para a pasta de envio. */
    fun audios(ctx: Context, nb: Notebook, dir: File): List<File> {
        val src = (dir.listFiles()?.filter { it.name.startsWith("audio_") } ?: emptyList()).sortedBy { it.name }
        return src.mapIndexed { i, f ->
            val out = File(outDir(ctx), safe(nb.title) + "_gravacao" + (i + 1) + ".m4a")
            f.copyTo(out, overwrite = true)
        }
    }

    fun share(ctx: Context, f: File, mime: String) = send(ctx, listOf(f), mime, Target.OTHER, "")

    enum class Target { WHATSAPP, EMAIL, OTHER }

    /** Envia um ou mais arquivos pelo WhatsApp, por e-mail ou por qualquer app. */
    fun send(ctx: Context, files: List<File>, mime: String, target: Target, title: String) {
        val uris = ArrayList<Uri>()
        for (f in files) uris.add(FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f))
        val i = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        i.type = if (uris.size == 1) mime else "*/*"
        val clip = ClipData.newRawUri("", uris[0])
        for (k in 1 until uris.size) clip.addItem(ClipData.Item(uris[k]))
        i.clipData = clip
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        when (target) {
            Target.WHATSAPP -> {
                for (pkg in arrayOf("com.whatsapp", "com.whatsapp.w4b")) {
                    try {
                        ctx.startActivity(Intent(i).setPackage(pkg))
                        return
                    } catch (e: ActivityNotFoundException) {
                        // tenta o próximo
                    }
                }
                Toast.makeText(ctx, "WhatsApp não encontrado. Escolha outro app.", Toast.LENGTH_LONG).show()
                ctx.startActivity(Intent.createChooser(i, "Enviar"))
            }
            Target.EMAIL -> {
                i.putExtra(Intent.EXTRA_SUBJECT, title)
                i.putExtra(Intent.EXTRA_TEXT, "Segue em anexo: $title")
                i.selector = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
                try {
                    ctx.startActivity(Intent.createChooser(i, "Enviar por e-mail"))
                } catch (e: Exception) {
                    i.selector = null
                    ctx.startActivity(Intent.createChooser(i, "Enviar"))
                }
            }
            Target.OTHER -> ctx.startActivity(Intent.createChooser(i, "Compartilhar ou salvar"))
        }
    }
}
